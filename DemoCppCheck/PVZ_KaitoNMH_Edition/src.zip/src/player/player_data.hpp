#pragma once
#include "player/player_name.hpp"

void read_savedata();
void update_unlocked_level();
void reset_unlocked_level();