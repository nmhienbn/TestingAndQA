#pragma once

void display_game_elements();
void display_game_layout();
void display_game_paused_elements();

void display_seed_packets_bar();
void display_chosen_plant();

void blink_row_and_col();