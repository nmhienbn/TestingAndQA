#pragma once

void display_ready_set_plant(const int &image_num);
void display_game_announce();