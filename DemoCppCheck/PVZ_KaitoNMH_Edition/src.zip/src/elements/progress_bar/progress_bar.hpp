#pragma once

void display_progress_bar();