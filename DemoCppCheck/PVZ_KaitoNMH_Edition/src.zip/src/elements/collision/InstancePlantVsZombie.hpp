#pragma once
#include "AttackPlantVsZombie.hpp"

void apply_instance_plant_hit_zombie(Plants &plant, vector<Zombie *> &zombies,
                                     vector<ZombiePart> &zombie_parts);