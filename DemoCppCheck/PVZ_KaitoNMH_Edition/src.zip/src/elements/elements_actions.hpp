#pragma once

void handle_changes();
void handle_movements();
void create_new_zombies();
void update_new_wave_zombies();
void update_plant_seeds_remaining_time();
