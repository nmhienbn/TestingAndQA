#pragma once

int rand(int L, int R);
bool is_in(const int &L, const int &x, const int &R);