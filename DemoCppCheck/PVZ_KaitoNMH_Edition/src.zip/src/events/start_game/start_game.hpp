#pragma once
#include "player/player_data.hpp"
#include "music/music.hpp"

void init_game();

void display_loading_screen();
void display_starting_screen();