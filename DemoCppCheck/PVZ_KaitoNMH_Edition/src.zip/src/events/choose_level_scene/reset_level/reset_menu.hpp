#pragma once

void display_game_reset();

void handle_reset_menu_click(const int &mouse_x, const int &mouse_y);