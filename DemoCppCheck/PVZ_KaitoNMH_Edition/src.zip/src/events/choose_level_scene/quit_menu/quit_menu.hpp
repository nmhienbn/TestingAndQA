#pragma once

void display_game_quit();

void handle_quit_menu_click(const int &mouse_x, const int &mouse_y);