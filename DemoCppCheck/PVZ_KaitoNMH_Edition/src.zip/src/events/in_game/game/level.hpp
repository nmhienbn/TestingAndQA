#pragma once

void start_level();
void display_all_in_game();