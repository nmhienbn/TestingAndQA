#pragma once
#include "draw/render_elements.hpp"
#include "music/music.hpp"
#include "player/player_data.hpp"

bool display_win();
bool has_player_won();