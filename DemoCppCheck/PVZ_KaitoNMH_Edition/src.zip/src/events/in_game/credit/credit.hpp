#pragma once

void display_credit();

void display_sod_roll();