#pragma once

void init_volume();
void handle_volume_change();
void display_slider();
