#pragma once
#include "draw/render_elements.hpp"

void display_game_leave();
void leave_game();
void handle_leave_menu_click(const int &mouse_x, const int &mouse_y);