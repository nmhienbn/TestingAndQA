#pragma once

void display_losing_message();
bool has_player_lost();
void display_lose();