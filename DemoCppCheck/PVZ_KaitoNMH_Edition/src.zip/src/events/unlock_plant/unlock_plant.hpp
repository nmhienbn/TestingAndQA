#pragma once
#include "draw/render_elements.hpp"
#include "music/music.hpp"

void display_unlock_plant(const int &new_plant_dir);
void unlock_plant(const int &_plant_type);